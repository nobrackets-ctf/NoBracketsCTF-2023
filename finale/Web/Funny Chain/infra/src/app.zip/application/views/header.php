<?php header("Content-type: text/html; charset=utf-8"); ?>
<!DOCTYPE html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="<?php echo base_url()?>assets/bootstrap-4.3.1-dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php echo base_url()?>assets/fontawesome-5.11.2/css/all.css" rel="stylesheet">
</head>
